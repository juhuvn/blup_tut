# construct pedigree-based relationship matrix (RM)

# additive RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --add \
  --thread 4 \
  --out demo

# inverse of additive RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --add-inv \
  --thread 4 \
  --out demo

# dominant RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --dom \
  --thread 4 \
  --out demo

# inverse of dominant RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --dom-inv \
  --thread 4 \
  --out demo
