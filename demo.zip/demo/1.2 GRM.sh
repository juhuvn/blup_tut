# construct genomic relationship matrix (RM)

# additive RM
../hiblup \
  --make-xrm \
  --bfile demo \
  --add \
  --step 100000 \
  --thread 4 \
  --out demo
# --snp-weight snp.weght.txt # calculate weighted GRM
# --exclude snp.filter.txt # remove a subset of SNPs when constructing GRM

# inverse of additive RM
../hiblup \
  --make-xrm \
  --bfile demo \
  --add-inv \
  --step 100000 \
  --thread 4 \
  --out demo

# dominant RM
../hiblup \
  --make-xrm \
  --bfile demo \
  --dom \
  --step 100000 \
  --thread 4 \
  --out demo

# inverse of dominant RM
../hiblup \
  --make-xrm \
  --bfile demo \
  --dom-inv \
  --step 100000 \
  --dom-inv \
  --thread 4 \
  --out demo
