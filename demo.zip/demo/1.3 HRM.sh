# construct pedigree and genome based relationship matrix (RM) for SSGBLUP model

# additive RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --bfile demo \
  --alpha 0.05 \
  --add \
  --step 100000 \
  --thread 4 \
  --out demo

# inverse of additive RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --bfile demo \
  --alpha 0.05 \
  --add-inv \
  --ridge-value 0.001 \
  --step 100000 \
  --thread 4 \
  --out demo

# dominant RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --bfile demo \
  --alpha 0.05 \
  --dom \
  --step 100000 \
  --thread 4 \
  --out demo

# inverse of dominant RM
../hiblup \
  --make-xrm \
  --pedigree demo.ped \
  --bfile demo \
  --alpha 0.05 \
  --dom-inv \
  --step 100000 \
  --dom-inv \
  --thread 4 \
  --out demo
