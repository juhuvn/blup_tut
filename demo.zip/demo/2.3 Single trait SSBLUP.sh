../hiblup \
  --single-trait \
  --pheno demo.phe \
  --pheno-pos 8 \
  --dcovar 2,3 \
  --qcovar 4,5 \
  --rand 6,7 \
  --bfile demo \
  --pedigree demo.ped \
  --add \
  --dom \
  --threads 4 \
  --out demo
# --snp-effect # to calculate the SNP effects of rrBLUP model 
  