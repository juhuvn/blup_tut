# run GBLUP model
../hiblup \
  --single-trait \
  --pheno demo.repeat.phe \
  --pheno-pos 8 \
  --dcovar 2,3 \
  --qcovar 4,5 \
  --rand 1,6,7 \
  --bfile demo \
  --add \
  --threads 4 \
  --out demo
