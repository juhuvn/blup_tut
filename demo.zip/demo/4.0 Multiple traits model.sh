# run additive and dominant GBLUP model
../hiblup \
  --multi-trait \
  --pheno demo.phe \
  --pheno-pos 8 9 10 \
  --dcovar 2,3 0 2 \
  --qcovar 4,5 5 4 \
  --rand 6,7 7 0 \
  --bfile demo \
  --add \
  --dom \
  --threads 4 \
  --out demo
