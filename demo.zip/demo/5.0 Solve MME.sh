# solve mixed model equation for single trait model
../hiblup \
  --mme \
  --pheno demo.phe \
  --pheno-pos 8 \
  --dcovar 2,3 \
  --qcovar 4,5 \
  --rand 6,7 \
  --bfile demo \
  --add \
  --dom \
  --vc-priors 4.3320,4.2366,51.2665,19.8490,21.6205 \
  --threads 4 \
  --out demo
# --pcg  # use PCG algorithm for fast solver when using very large dataset

# solve mixed model equation for multiple traits model
../hiblup \
  --mme \
  --pheno demo.phe \
  --pheno-pos 8 9 10 \
  --dcovar 2,3 0 2 \
  --qcovar 4,5 5 4 \
  --rand 6,7 7 0 \
  --bfile demo \
  --add \
  --dom \
  --vc-priors 4.3320,4.2366,51.2665,19.8490,21.6205 8.9389,33.0674,35.1326,13.6825 7.9357,26.8970,67.7977 \
  --covc-priors 32.2089,10.5777,2.3076 12.9885,3.0128,21.1620 0.5118,0.0410,-1.6757 \
  --threads 4 \
  --out demo
# --pcg  # use PCG algorithm for fast solver when using very large dataset
