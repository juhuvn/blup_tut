../hiblup \
  --mating \
  --bfile demo \
  --score demo.snpeff \
  --add \
  --dom \
  --out test
